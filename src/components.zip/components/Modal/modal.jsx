import React from "react";
import modalStyles from "./modal.module.css";
import ReactDOM from 'react-dom'


const modalRoot = document.getElementById("modal");

const Modal = ({children, onClose}) => {


    return ReactDOM.createPortal(
            
                <>
                    <div className={modalStyles.container}>
        <button type="button" aria-label="Закрыть" className="button"></button>

          {children}
      </div>
                </>
            , 
            modalRoot
        );
  }


  export default Modal